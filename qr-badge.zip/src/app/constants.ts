export const URL =  {

  url : 'http://localhost:3200/' // local ip

 }
